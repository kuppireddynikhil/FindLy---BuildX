-- ============================================================
-- FINDLY — ROW LEVEL SECURITY & STORAGE POLICIES (05_rls_and_storage.sql)
-- SVCE Tirupati | BuildX Club | Coffee Coders
-- ============================================================

-- Enable RLS on all relational tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversation_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE recovery_cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE campuses ENABLE ROW LEVEL SECURITY;
ALTER TABLE buildings ENABLE ROW LEVEL SECURITY;
ALTER TABLE floors ENABLE ROW LEVEL SECURITY;
ALTER TABLE campus_locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;

-- Helper function: Is current user an admin?
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  );
$$;

-- 1. Profiles Policies
CREATE POLICY "Profiles viewable by owner or admin"
  ON profiles FOR SELECT
  USING (auth.uid() = id OR is_admin());

CREATE POLICY "Profiles updatable by owner"
  ON profiles FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- 2. Reports Policies
CREATE POLICY "Active reports readable by authenticated users"
  ON reports FOR SELECT
  USING (
    status IN ('ACTIVE', 'open', 'MATCHED', 'RECOVERED')
    OR reporter_id = auth.uid()
    OR is_admin()
  );

CREATE POLICY "Authenticated users can create reports"
  ON reports FOR INSERT
  WITH CHECK (auth.uid() = reporter_id);

CREATE POLICY "Reporters or admins can update reports"
  ON reports FOR UPDATE
  USING (reporter_id = auth.uid() OR is_admin())
  WITH CHECK (reporter_id = auth.uid() OR is_admin());

-- 3. Report Images Policies
CREATE POLICY "Report images readable with report"
  ON report_images FOR SELECT
  USING (TRUE);

CREATE POLICY "Reporters can insert report images"
  ON report_images FOR INSERT
  WITH CHECK (
    EXISTS (SELECT 1 FROM reports WHERE id = report_id AND reporter_id = auth.uid())
    OR is_admin()
  );

-- 4. Matches Policies
CREATE POLICY "Matches viewable by parties or admin"
  ON matches FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM reports r
      WHERE (r.id = lost_report_id OR r.id = found_report_id)
      AND r.reporter_id = auth.uid()
    )
    OR is_admin()
  );

-- 5. Conversations Policies
CREATE POLICY "Conversations viewable by participants or admin"
  ON conversations FOR SELECT
  USING (
    requester_id = auth.uid() 
    OR reporter_id = auth.uid() 
    OR is_admin()
  );

CREATE POLICY "Authenticated users can initiate conversations"
  ON conversations FOR INSERT
  WITH CHECK (requester_id = auth.uid());

CREATE POLICY "Participants can update conversations"
  ON conversations FOR UPDATE
  USING (requester_id = auth.uid() OR reporter_id = auth.uid() OR is_admin());

-- 6. Messages Policies
CREATE POLICY "Messages viewable by conversation participants or admin"
  ON messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = conversation_id
      AND (c.requester_id = auth.uid() OR c.reporter_id = auth.uid())
    )
    OR is_admin()
  );

CREATE POLICY "Messages insertable by sender"
  ON messages FOR INSERT
  WITH CHECK (auth.uid() = sender_id);

-- 7. Notifications Policies
CREATE POLICY "Users can only read own notifications"
  ON notifications FOR SELECT
  USING (profile_id = auth.uid() OR user_id = auth.uid());

CREATE POLICY "Users can update own notification read state"
  ON notifications FOR UPDATE
  USING (profile_id = auth.uid() OR user_id = auth.uid())
  WITH CHECK (profile_id = auth.uid() OR user_id = auth.uid());

-- 8. Recovery Cases Policies
CREATE POLICY "Recovery cases viewable by claimant, finder, or admin"
  ON recovery_cases FOR SELECT
  USING (
    claimant_id = auth.uid()
    OR finder_id = auth.uid()
    OR is_admin()
  );

CREATE POLICY "Admins can update recovery cases"
  ON recovery_cases FOR ALL
  USING (is_admin());

-- 9. Campus Directory & Reference Data (Readable by all authenticated users)
CREATE POLICY "Campus entities readable by all" ON campuses FOR SELECT USING (TRUE);
CREATE POLICY "Buildings readable by all" ON buildings FOR SELECT USING (TRUE);
CREATE POLICY "Floors readable by all" ON floors FOR SELECT USING (TRUE);
CREATE POLICY "Locations readable by all" ON campus_locations FOR SELECT USING (TRUE);
CREATE POLICY "Categories readable by all" ON categories FOR SELECT USING (TRUE);
CREATE POLICY "Departments readable by all" ON departments FOR SELECT USING (TRUE);
CREATE POLICY "Roles readable by all" ON roles FOR SELECT USING (TRUE);

-- Campus mutations restricted to admins
CREATE POLICY "Campus mutable by admin only" ON campuses FOR ALL USING (is_admin());
CREATE POLICY "Buildings mutable by admin only" ON buildings FOR ALL USING (is_admin());
CREATE POLICY "Floors mutable by admin only" ON floors FOR ALL USING (is_admin());
CREATE POLICY "Locations mutable by admin only" ON campus_locations FOR ALL USING (is_admin());

-- 10. Audit Logs Policies
CREATE POLICY "Audit logs viewable by admin only"
  ON audit_logs FOR SELECT
  USING (is_admin());

CREATE POLICY "Audit logs insertable by any authenticated action"
  ON audit_logs FOR INSERT
  WITH CHECK (TRUE);

-- Storage Buckets Configuration
INSERT INTO storage.buckets (id, name, public)
VALUES 
  ('report-images', 'report-images', true),
  ('avatars', 'avatars', true),
  ('message-attachments', 'message-attachments', false)
ON CONFLICT (id) DO NOTHING;
