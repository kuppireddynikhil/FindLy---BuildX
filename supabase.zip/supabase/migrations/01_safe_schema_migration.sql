-- ============================================================
-- FINDLY — SAFE SUPABASE MIGRATION (01_safe_schema_migration.sql)
-- SVCE Tirupati | BuildX Club | Coffee Coders
-- ============================================================
-- Non-destructive: Does NOT drop or truncate any existing tables.
-- Extends existing profiles and creates remaining relational tables.

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. Departments Table
CREATE TABLE IF NOT EXISTS departments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Roles Table
CREATE TABLE IF NOT EXISTS roles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE, -- 'user', 'admin', 'super_admin'
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Campuses Table
CREATE TABLE IF NOT EXISTS campuses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Buildings Table
CREATE TABLE IF NOT EXISTS buildings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  campus_id UUID REFERENCES campuses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  code TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Floors Table
CREATE TABLE IF NOT EXISTS floors (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  building_id UUID REFERENCES buildings(id) ON DELETE CASCADE,
  floor_number INTEGER NOT NULL,
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Campus Locations Table
CREATE TABLE IF NOT EXISTS campus_locations (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  floor_id UUID REFERENCES floors(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  building TEXT,
  floor TEXT,
  room TEXT,
  location_type TEXT DEFAULT 'general',
  latitude NUMERIC(10, 7),
  longitude NUMERIC(10, 7),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Categories Table
CREATE TABLE IF NOT EXISTS categories (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  icon TEXT,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Safely Alter Profiles Table
-- Ensure profiles table exists
CREATE TABLE IF NOT EXISTS profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT NOT NULL,
  full_name TEXT,
  phone TEXT,
  department TEXT,
  avatar_url TEXT,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin', 'super_admin')),
  account_status TEXT NOT NULL DEFAULT 'active' CHECK (account_status IN ('active', 'disabled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Add missing columns safely
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS username TEXT UNIQUE;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS institutional_id TEXT;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS department_id UUID REFERENCES departments(id) ON DELETE SET NULL;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE;

-- 9. User Roles Table (Relational Role Mapping)
CREATE TABLE IF NOT EXISTS user_roles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  profile_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  role_id UUID REFERENCES roles(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(profile_id, role_id)
);

-- 10. Reports Table
CREATE TABLE IF NOT EXISTS reports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  item_id UUID,
  reporter_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('LOST', 'FOUND', 'lost', 'found')),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  brand TEXT,
  color TEXT,
  identifying_features TEXT,
  campus_location_id UUID REFERENCES campus_locations(id) ON DELETE SET NULL,
  location_description TEXT,
  building TEXT,
  floor TEXT,
  room_area TEXT,
  latitude NUMERIC(10, 7),
  longitude NUMERIC(10, 7),
  date DATE DEFAULT CURRENT_DATE,
  time TIME,
  image_url TEXT,
  contact_method TEXT DEFAULT 'findly_messaging',
  contact_info TEXT,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('PENDING_REVIEW', 'ACTIVE', 'MATCHED', 'RECOVERED', 'WITHDRAWN', 'REJECTED', 'open', 'pending', 'claimed', 'resolved', 'closed', 'archived', 'flagged')),
  is_searchable BOOLEAN DEFAULT TRUE,
  reported_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. Report Images Table
CREATE TABLE IF NOT EXISTS report_images (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  report_id UUID REFERENCES reports(id) ON DELETE CASCADE NOT NULL,
  image_url TEXT NOT NULL,
  is_primary BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. Matches Table (Deterministic Matching)
CREATE TABLE IF NOT EXISTS matches (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  lost_report_id UUID REFERENCES reports(id) ON DELETE CASCADE NOT NULL,
  found_report_id UUID REFERENCES reports(id) ON DELETE CASCADE NOT NULL,
  score NUMERIC(5, 2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'SUGGESTED' CHECK (status IN ('SUGGESTED', 'CONFIRMED', 'DISMISSED')),
  match_reasons JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(lost_report_id, found_report_id)
);

-- 13. Conversations Table (Controlled Messaging)
CREATE TABLE IF NOT EXISTS conversations (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  report_id UUID REFERENCES reports(id) ON DELETE CASCADE,
  requester_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  reporter_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'ACCEPTED', 'ACTIVE', 'DECLINED', 'REVOKED', 'CLOSED', 'EXPIRED')),
  requester_message_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 14. Conversation Participants Table
CREATE TABLE IF NOT EXISTS conversation_participants (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  conversation_id UUID REFERENCES conversations(id) ON DELETE CASCADE NOT NULL,
  profile_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  role TEXT NOT NULL DEFAULT 'participant',
  joined_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(conversation_id, profile_id)
);

-- 15. Messages Table
CREATE TABLE IF NOT EXISTS messages (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  conversation_id UUID REFERENCES conversations(id) ON DELETE CASCADE NOT NULL,
  sender_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  content TEXT NOT NULL,
  attachment_url TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 16. Recovery Cases Table
CREATE TABLE IF NOT EXISTS recovery_cases (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  case_number TEXT UNIQUE,
  match_id UUID REFERENCES matches(id) ON DELETE SET NULL,
  report_id UUID REFERENCES reports(id) ON DELETE CASCADE,
  claimant_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  finder_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'VERIFIED', 'HANDOVER_SCHEDULED', 'COMPLETED', 'REJECTED', 'CANCELLED')),
  handover_date TIMESTAMPTZ,
  handover_location TEXT DEFAULT 'SVCE Tirupati Campus Security & Student Affairs Desk',
  notes TEXT,
  verified_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
  verified_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 17. Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  profile_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  item_id UUID,
  report_id UUID,
  claim_id UUID,
  conversation_id UUID,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL,
  link TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 18. Audit Logs Table
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  actor_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 19. Performance Indexes
CREATE INDEX IF NOT EXISTS idx_reports_reporter_id ON reports(reporter_id);
CREATE INDEX IF NOT EXISTS idx_reports_type ON reports(type);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
CREATE INDEX IF NOT EXISTS idx_reports_reported_at ON reports(reported_at);
CREATE INDEX IF NOT EXISTS idx_reports_campus_location_id ON reports(campus_location_id);
CREATE INDEX IF NOT EXISTS idx_matches_lost_report_id ON matches(lost_report_id);
CREATE INDEX IF NOT EXISTS idx_matches_found_report_id ON matches(found_report_id);
CREATE INDEX IF NOT EXISTS idx_matches_status ON matches(status);
CREATE INDEX IF NOT EXISTS idx_conversations_requester_id ON conversations(requester_id);
CREATE INDEX IF NOT EXISTS idx_conversations_reporter_id ON conversations(reporter_id);
CREATE INDEX IF NOT EXISTS idx_conversations_status ON conversations(status);
CREATE INDEX IF NOT EXISTS idx_messages_conversation_id_created_at ON messages(conversation_id, created_at);
CREATE INDEX IF NOT EXISTS idx_notifications_profile_id_is_read ON notifications(profile_id, is_read);
CREATE INDEX IF NOT EXISTS idx_recovery_cases_status ON recovery_cases(status);
CREATE INDEX IF NOT EXISTS idx_user_roles_profile_id_role_id ON user_roles(profile_id, role_id);

-- ============================================================
-- Seed Initial SVCE Departments, Roles, Campuses & Buildings
-- ============================================================
INSERT INTO departments (name, code) VALUES
  ('Computer Science and Engineering', 'CSE'),
  ('Information Technology', 'IT'),
  ('Electronics and Communication Engineering', 'ECE'),
  ('Electrical and Electronics Engineering', 'EEE'),
  ('Mechanical Engineering', 'MECH'),
  ('Civil Engineering', 'CIVIL'),
  ('Master of Business Administration', 'MBA'),
  ('Master of Computer Applications', 'MCA'),
  ('Campus Administration & Security', 'ADMIN')
ON CONFLICT (code) DO NOTHING;

INSERT INTO roles (name, description) VALUES
  ('user', 'Standard campus student, faculty, or staff member'),
  ('admin', 'Campus Lost & Found moderator and security coordinator'),
  ('super_admin', 'Head campus administrator with full privileges')
ON CONFLICT (name) DO NOTHING;

INSERT INTO campuses (name, code, address) VALUES
  ('SVCE Main Campus', 'SVCE-TPT', 'Karakambadi Road, SVCE Tirupati, Andhra Pradesh 517507')
ON CONFLICT (code) DO NOTHING;

DO $$
DECLARE
  v_campus_id UUID;
  v_bldg_main UUID;
  v_bldg_cs UUID;
  v_bldg_ece UUID;
  v_bldg_lib UUID;
  v_bldg_cafe UUID;
  v_floor_id UUID;
BEGIN
  SELECT id INTO v_campus_id FROM campuses WHERE code = 'SVCE-TPT' LIMIT 1;

  INSERT INTO buildings (campus_id, name, code)
  VALUES (v_campus_id, 'Main Administrative Block', 'MAIN')
  ON CONFLICT DO NOTHING RETURNING id INTO v_bldg_main;

  INSERT INTO buildings (campus_id, name, code)
  VALUES (v_campus_id, 'CSE & IT Engineering Block', 'CS-IT')
  ON CONFLICT DO NOTHING RETURNING id INTO v_bldg_cs;

  INSERT INTO buildings (campus_id, name, code)
  VALUES (v_campus_id, 'Central Library', 'LIB')
  ON CONFLICT DO NOTHING RETURNING id INTO v_bldg_lib;

  INSERT INTO buildings (campus_id, name, code)
  VALUES (v_campus_id, 'Student Cafeteria & Food Court', 'CAFE')
  ON CONFLICT DO NOTHING RETURNING id INTO v_bldg_cafe;

  -- Seed SVCE campus locations if empty
  IF NOT EXISTS (SELECT 1 FROM campus_locations LIMIT 1) THEN
    INSERT INTO campus_locations (name, building, floor, room, location_type, latitude, longitude) VALUES
      ('Central Library Reading Hall', 'Central Library', '1st Floor', 'Reading Hall A', 'library', 13.6288, 79.4192),
      ('Digital Library & Research Lab', 'Central Library', '2nd Floor', 'DL-204', 'lab', 13.6289, 79.4193),
      ('Main Canteen & Student Dining', 'Student Cafeteria', 'Ground Floor', 'Dining Area', 'cafeteria', 13.6282, 79.4185),
      ('CSE Advanced Computing Lab 1', 'CSE & IT Engineering Block', '1st Floor', 'Lab CS-101', 'lab', 13.6295, 79.4201),
      ('CSE Department Seminar Hall', 'CSE & IT Engineering Block', '3rd Floor', 'Seminar Hall 3', 'hall', 13.6296, 79.4203),
      ('Auditorium & Cultural Hall', 'Main Administrative Block', 'Ground Floor', 'Main Auditorium', 'auditorium', 13.6275, 79.4178),
      ('Administrative Office & Helpdesk', 'Main Administrative Block', '1st Floor', 'Room 102', 'office', 13.6276, 79.4179),
      ('Indoor Sports Complex', 'Sports Complex', 'Ground Floor', 'Badminton Courts', 'sports', 13.6268, 79.4165),
      ('Open Air Amphitheatre', 'Campus Grounds', 'Ground Floor', 'Amphitheatre', 'outdoor', 13.6280, 79.4190);
  END IF;

  -- Seed default categories if empty
  IF NOT EXISTS (SELECT 1 FROM categories LIMIT 1) THEN
    INSERT INTO categories (name, icon, description) VALUES
      ('Electronics & Gadgets', 'Laptop', 'Laptops, smartphones, chargers, headphones, pendrives, smartwatches'),
      ('ID Cards & Documents', 'CreditCard', 'Student identity cards, driving licenses, hall tickets, certificates, wallets'),
      ('Bags & Backpacks', 'Backpack', 'College backpacks, laptop sleeves, gym bags, pouches, handbags'),
      ('Keys & Access Cards', 'Key', 'Bike keys, hostel room keys, locker keys, laboratory access cards'),
      ('Books & Stationery', 'BookOpen', 'Textbooks, notebooks, scientific calculators, engineering drawing kits'),
      ('Clothing & Accessories', 'Watch', 'Jackets, sweaters, sunglasses, watches, umbrellas, water bottles'),
      ('Personal Belongings', 'Package', 'Miscellaneous personal items, jewelry, sports equipment');
  END IF;
END $$;
