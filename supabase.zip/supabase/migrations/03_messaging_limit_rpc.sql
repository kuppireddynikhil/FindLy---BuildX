-- ============================================================
-- FINDLY — CONTROLLED MESSAGING RPC (03_messaging_limit_rpc.sql)
-- SVCE Tirupati | BuildX Club | Coffee Coders
-- ============================================================
-- Server-enforced 2-message preliminary limit for requesters.
-- Conversation lifecycle: PENDING -> ACCEPTED -> ACTIVE
-- Alternative: DECLINED, REVOKED, CLOSED, EXPIRED.

CREATE OR REPLACE FUNCTION send_conversation_message(
  p_conversation_id UUID,
  p_sender_id UUID,
  p_content TEXT,
  p_attachment_url TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_conv RECORD;
  v_new_msg_id UUID;
  v_other_participant_id UUID;
  v_is_requester BOOLEAN;
BEGIN
  -- 1. Fetch conversation
  SELECT * INTO v_conv FROM conversations WHERE id = p_conversation_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Conversation does not exist';
  END IF;

  -- 2. Verify participation
  IF p_sender_id != v_conv.requester_id AND p_sender_id != v_conv.reporter_id THEN
    RAISE EXCEPTION 'Unauthorized: sender is not a participant in this conversation';
  END IF;

  v_is_requester := (p_sender_id = v_conv.requester_id);
  IF v_is_requester THEN
    v_other_participant_id := v_conv.reporter_id;
  ELSE
    v_other_participant_id := v_conv.requester_id;
  END IF;

  -- 3. Check conversation status
  IF v_conv.status IN ('DECLINED', 'REVOKED', 'CLOSED', 'EXPIRED') THEN
    RAISE EXCEPTION 'Chat access has been revoked or closed (%s)', v_conv.status;
  END IF;

  -- 4. Enforce 2-message preliminary limit for requester
  IF v_conv.status = 'PENDING' AND v_is_requester THEN
    IF v_conv.requester_message_count >= 2 THEN
      RAISE EXCEPTION 'Preliminary message limit reached (2 messages maximum). Awaiting reporter acceptance before further messages can be sent.';
    END IF;
  END IF;

  -- 5. If responder replies while PENDING, automatically transition to ACTIVE
  IF v_conv.status = 'PENDING' AND NOT v_is_requester THEN
    UPDATE conversations
    SET status = 'ACTIVE', updated_at = NOW()
    WHERE id = p_conversation_id;
  END IF;

  -- 6. Insert message
  INSERT INTO messages (conversation_id, sender_id, content, attachment_url, is_read, created_at)
  VALUES (p_conversation_id, p_sender_id, p_content, p_attachment_url, FALSE, NOW())
  RETURNING id INTO v_new_msg_id;

  -- 7. If sender is requester, increment message count
  IF v_is_requester THEN
    UPDATE conversations
    SET requester_message_count = requester_message_count + 1, updated_at = NOW()
    WHERE id = p_conversation_id;
  ELSE
    UPDATE conversations
    SET updated_at = NOW()
    WHERE id = p_conversation_id;
  END IF;

  -- 8. Notify recipient
  INSERT INTO notifications (profile_id, user_id, conversation_id, title, message, type, link)
  VALUES (
    v_other_participant_id,
    v_other_participant_id,
    p_conversation_id,
    'New Message on Findly',
    p_content,
    'new_message',
    format('/messages?conversation=%s', p_conversation_id)
  );

  RETURN jsonb_build_object(
    'success', true,
    'message_id', v_new_msg_id,
    'conversation_id', p_conversation_id,
    'status', (SELECT status FROM conversations WHERE id = p_conversation_id)
  );
END;
$$;

-- Accept conversation
CREATE OR REPLACE FUNCTION accept_conversation(p_conversation_id UUID, p_actor_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_conv RECORD;
BEGIN
  SELECT * INTO v_conv FROM conversations WHERE id = p_conversation_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Conversation not found';
  END IF;

  IF p_actor_id != v_conv.reporter_id THEN
    RAISE EXCEPTION 'Only the reporter/finder can accept this chat request';
  END IF;

  UPDATE conversations SET status = 'ACTIVE', updated_at = NOW() WHERE id = p_conversation_id;

  INSERT INTO notifications (profile_id, user_id, conversation_id, title, message, type, link)
  VALUES (
    v_conv.requester_id,
    v_conv.requester_id,
    p_conversation_id,
    'Chat Request Accepted!',
    'Your message request has been accepted. You can now chat freely.',
    'chat_accepted',
    format('/messages?conversation=%s', p_conversation_id)
  );

  RETURN jsonb_build_object('success', true, 'status', 'ACTIVE');
END;
$$;

-- Decline conversation
CREATE OR REPLACE FUNCTION decline_conversation(p_conversation_id UUID, p_actor_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_conv RECORD;
BEGIN
  SELECT * INTO v_conv FROM conversations WHERE id = p_conversation_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Conversation not found';
  END IF;

  IF p_actor_id != v_conv.reporter_id THEN
    RAISE EXCEPTION 'Only the reporter/finder can decline this chat request';
  END IF;

  UPDATE conversations SET status = 'DECLINED', updated_at = NOW() WHERE id = p_conversation_id;

  INSERT INTO notifications (profile_id, user_id, conversation_id, title, message, type, link)
  VALUES (
    v_conv.requester_id,
    v_conv.requester_id,
    p_conversation_id,
    'Chat Request Declined',
    'The finder has declined this communication request.',
    'chat_declined',
    format('/messages?conversation=%s', p_conversation_id)
  );

  RETURN jsonb_build_object('success', true, 'status', 'DECLINED');
END;
$$;

-- Revoke conversation
CREATE OR REPLACE FUNCTION revoke_conversation(p_conversation_id UUID, p_actor_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_conv RECORD;
BEGIN
  SELECT * INTO v_conv FROM conversations WHERE id = p_conversation_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Conversation not found';
  END IF;

  IF p_actor_id != v_conv.requester_id AND p_actor_id != v_conv.reporter_id THEN
    RAISE EXCEPTION 'Unauthorized to revoke this conversation';
  END IF;

  UPDATE conversations SET status = 'REVOKED', updated_at = NOW() WHERE id = p_conversation_id;

  INSERT INTO notifications (profile_id, user_id, conversation_id, title, message, type, link)
  VALUES (
    CASE WHEN p_actor_id = v_conv.requester_id THEN v_conv.reporter_id ELSE v_conv.requester_id END,
    CASE WHEN p_actor_id = v_conv.requester_id THEN v_conv.reporter_id ELSE v_conv.requester_id END,
    p_conversation_id,
    'Chat Access Revoked',
    'Chat access has been revoked for this conversation.',
    'chat_revoked',
    format('/messages?conversation=%s', p_conversation_id)
  );

  RETURN jsonb_build_object('success', true, 'status', 'REVOKED');
END;
$$;
