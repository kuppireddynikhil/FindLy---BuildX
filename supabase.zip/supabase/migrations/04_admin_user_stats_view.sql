-- ============================================================
-- FINDLY — ADMIN USER REPORT STATISTICS (04_admin_user_stats_view.sql)
-- SVCE Tirupati | BuildX Club | Coffee Coders
-- ============================================================
-- Calculates real aggregate report counts:
-- Lost Count = COUNT(*) WHERE reporter_id = profile.id AND type = 'LOST'
-- Found Count = COUNT(*) WHERE reporter_id = profile.id AND type = 'FOUND'
-- Total = Lost + Found

CREATE OR REPLACE VIEW user_report_statistics AS
SELECT 
  p.id AS profile_id,
  p.email,
  p.full_name,
  p.username,
  p.phone,
  p.department,
  p.department_id,
  p.avatar_url,
  p.role,
  p.is_active,
  p.account_status,
  p.created_at AS joined_date,
  COALESCE(SUM(CASE WHEN UPPER(r.type) = 'LOST' THEN 1 ELSE 0 END), 0)::BIGINT AS lost_reports_count,
  COALESCE(SUM(CASE WHEN UPPER(r.type) = 'FOUND' THEN 1 ELSE 0 END), 0)::BIGINT AS found_reports_count,
  COALESCE(COUNT(r.id), 0)::BIGINT AS total_reports_count
FROM profiles p
LEFT JOIN reports r ON r.reporter_id = p.id
GROUP BY 
  p.id, p.email, p.full_name, p.username, p.phone, p.department, 
  p.department_id, p.avatar_url, p.role, p.is_active, p.account_status, p.created_at;

-- RPC Function for paginated, searchable user statistics in Admin Users page
CREATE OR REPLACE FUNCTION get_admin_user_statistics(
  p_search TEXT DEFAULT NULL,
  p_role_filter TEXT DEFAULT NULL,
  p_limit INT DEFAULT 50,
  p_offset INT DEFAULT 0
)
RETURNS TABLE (
  profile_id UUID,
  email TEXT,
  full_name TEXT,
  username TEXT,
  phone TEXT,
  department TEXT,
  role TEXT,
  is_active BOOLEAN,
  account_status TEXT,
  joined_date TIMESTAMPTZ,
  lost_reports_count BIGINT,
  found_reports_count BIGINT,
  total_reports_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    u.profile_id,
    u.email,
    u.full_name,
    u.username,
    u.phone,
    u.department,
    u.role,
    u.is_active,
    u.account_status,
    u.joined_date,
    u.lost_reports_count,
    u.found_reports_count,
    u.total_reports_count
  FROM user_report_statistics u
  WHERE (
    p_search IS NULL 
    OR u.full_name ILIKE '%' || p_search || '%'
    OR u.email ILIKE '%' || p_search || '%'
    OR u.username ILIKE '%' || p_search || '%'
    OR u.department ILIKE '%' || p_search || '%'
  )
  AND (
    p_role_filter IS NULL 
    OR u.role = p_role_filter
  )
  ORDER BY u.total_reports_count DESC, u.joined_date DESC
  LIMIT p_limit
  OFFSET p_offset;
END;
$$;
