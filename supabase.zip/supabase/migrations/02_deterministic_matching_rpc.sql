-- ============================================================
-- FINDLY — DETERMINISTIC MATCHING RPC (02_deterministic_matching_rpc.sql)
-- SVCE Tirupati | BuildX Club | Coffee Coders
-- ============================================================
-- Formula (Total 100%):
-- 1. Keyword Similarity (30%)
-- 2. Category Match (20%)
-- 3. Location Proximity (20%)
-- 4. Date/Time Proximity (15%)
-- 5. Description Similarity (15%)

CREATE OR REPLACE FUNCTION run_deterministic_matching_for_report(p_report_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_source RECORD;
  v_candidate RECORD;
  v_is_source_lost BOOLEAN;
  v_score NUMERIC(5, 2);
  v_keyword_score NUMERIC(5, 2);
  v_category_score NUMERIC(5, 2);
  v_location_score NUMERIC(5, 2);
  v_date_score NUMERIC(5, 2);
  v_desc_score NUMERIC(5, 2);
  v_source_words TEXT[];
  v_cand_words TEXT[];
  v_common_words INT;
  v_total_words INT;
  v_days_diff INT;
  v_match_reasons JSONB;
  v_matches_created INT := 0;
  v_lost_id UUID;
  v_found_id UUID;
  v_threshold NUMERIC(5, 2) := 45.0; -- Configurable minimum score to record match
BEGIN
  -- 1. Fetch source report
  SELECT * INTO v_source FROM reports WHERE id = p_report_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Report not found');
  END IF;

  v_is_source_lost := (UPPER(v_source.type) = 'LOST');

  -- Extract source title words (lowercase, alphanumeric)
  v_source_words := regexp_split_to_array(lower(regexp_replace(v_source.title, '[^a-zA-Z0-9 ]', '', 'g')), '\s+');

  -- 2. Iterate over candidate reports of opposite type with ACTIVE status
  FOR v_candidate IN
    SELECT r.*
    FROM reports r
    WHERE (
      (v_is_source_lost AND UPPER(r.type) = 'FOUND')
      OR
      (NOT v_is_source_lost AND UPPER(r.type) = 'LOST')
    )
    AND UPPER(r.status) IN ('ACTIVE', 'PENDING_REVIEW')
    AND r.id != p_report_id
  LOOP
    -- A. Keyword similarity (30% weight)
    v_cand_words := regexp_split_to_array(lower(regexp_replace(v_candidate.title, '[^a-zA-Z0-9 ]', '', 'g')), '\s+');
    
    SELECT count(*) INTO v_common_words
    FROM (
      SELECT unnest(v_source_words)
      INTERSECT
      SELECT unnest(v_cand_words)
    ) s WHERE length(s.unnest) > 2;

    v_total_words := GREATEST(array_length(v_source_words, 1), array_length(v_cand_words, 1), 1);
    v_keyword_score := LEAST(30.0, ROUND((v_common_words::numeric / v_total_words::numeric) * 30.0, 2));

    -- B. Category Match (20% weight)
    IF lower(COALESCE(v_source.category, '')) = lower(COALESCE(v_candidate.category, '')) THEN
      v_category_score := 20.0;
    ELSE
      v_category_score := 0.0;
    END IF;

    -- C. Location Proximity (20% weight)
    IF v_source.campus_location_id IS NOT NULL AND v_candidate.campus_location_id IS NOT NULL AND v_source.campus_location_id = v_candidate.campus_location_id THEN
      v_location_score := 20.0;
    ELSIF lower(COALESCE(v_source.building, '')) = lower(COALESCE(v_candidate.building, '')) AND length(COALESCE(v_source.building, '')) > 0 THEN
      v_location_score := 14.0;
    ELSIF v_source.latitude IS NOT NULL AND v_candidate.latitude IS NOT NULL THEN
      -- Approximate distance on campus scale (degrees)
      IF (abs(v_source.latitude - v_candidate.latitude) + abs(v_source.longitude - v_candidate.longitude)) < 0.0015 THEN
        v_location_score := 18.0;
      ELSIF (abs(v_source.latitude - v_candidate.latitude) + abs(v_source.longitude - v_candidate.longitude)) < 0.005 THEN
        v_location_score := 10.0;
      ELSE
        v_location_score := 0.0;
      END IF;
    ELSE
      v_location_score := 0.0;
    END IF;

    -- D. Date/Time Proximity (15% weight)
    v_days_diff := abs(COALESCE(v_source.date, v_source.created_at::date) - COALESCE(v_candidate.date, v_candidate.created_at::date));
    IF v_days_diff = 0 THEN
      v_date_score := 15.0;
    ELSIF v_days_diff <= 2 THEN
      v_date_score := 12.0;
    ELSIF v_days_diff <= 5 THEN
      v_date_score := 9.0;
    ELSIF v_days_diff <= 10 THEN
      v_date_score := 5.0;
    ELSE
      v_date_score := 0.0;
    END IF;

    -- E. Description Similarity (15% weight)
    DECLARE
      v_src_desc_words TEXT[];
      v_cand_desc_words TEXT[];
      v_common_desc INT;
    BEGIN
      v_src_desc_words := regexp_split_to_array(lower(regexp_replace(COALESCE(v_source.description, ''), '[^a-zA-Z0-9 ]', '', 'g')), '\s+');
      v_cand_desc_words := regexp_split_to_array(lower(regexp_replace(COALESCE(v_candidate.description, ''), '[^a-zA-Z0-9 ]', '', 'g')), '\s+');
      SELECT count(*) INTO v_common_desc
      FROM (
        SELECT unnest(v_src_desc_words)
        INTERSECT
        SELECT unnest(v_cand_desc_words)
      ) d WHERE length(d.unnest) > 3;

      v_desc_score := LEAST(15.0, ROUND((v_common_desc::numeric * 3.0), 2));
    END;

    -- Total Score
    v_score := v_keyword_score + v_category_score + v_location_score + v_date_score + v_desc_score;

    IF v_score >= v_threshold THEN
      IF v_is_source_lost THEN
        v_lost_id := v_source.id;
        v_found_id := v_candidate.id;
      ELSE
        v_lost_id := v_candidate.id;
        v_found_id := v_source.id;
      END IF;

      v_match_reasons := jsonb_build_object(
        'total_score', v_score,
        'keyword_score', v_keyword_score,
        'category_score', v_category_score,
        'location_score', v_location_score,
        'date_score', v_date_score,
        'description_score', v_desc_score,
        'explanation', format(
          'Score %s%%: Keyword (%s/30), Category %s (%s/20), Location (%s/20), Date within %s days (%s/15), Description (%s/15)',
          v_score, v_keyword_score, v_source.category, v_category_score, v_location_score, v_days_diff, v_date_score, v_desc_score
        )
      );

      -- Upsert match record
      INSERT INTO matches (lost_report_id, found_report_id, score, status, match_reasons, updated_at)
      VALUES (v_lost_id, v_found_id, v_score, 'SUGGESTED', v_match_reasons, NOW())
      ON CONFLICT (lost_report_id, found_report_id)
      DO UPDATE SET score = EXCLUDED.score, match_reasons = EXCLUDED.match_reasons, updated_at = NOW();

      v_matches_created := v_matches_created + 1;

      -- Create notifications for both reporter and finder
      INSERT INTO notifications (profile_id, user_id, report_id, title, message, type, link, metadata)
      VALUES 
        (
          v_source.reporter_id,
          v_source.reporter_id,
          v_source.id,
          'Potential Match Found!',
          format('A potential match (%s%% match score) was identified for "%s".', v_score, v_source.title),
          'potential_match',
          format('/items/%s', v_candidate.id),
          v_match_reasons
        ),
        (
          v_candidate.reporter_id,
          v_candidate.reporter_id,
          v_candidate.id,
          'Potential Match Identified!',
          format('A potential match (%s%% match score) was identified for "%s".', v_score, v_candidate.title),
          'potential_match',
          format('/items/%s', v_source.id),
          v_match_reasons
        );
    END IF;
  END LOOP;

  RETURN jsonb_build_object(
    'success', true,
    'report_id', p_report_id,
    'matches_evaluated', v_matches_created
  );
END;
$$;
